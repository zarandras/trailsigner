INSERT INTO public.sign_track_data (destination_text,distance_text_rounded,time_text_rounded,track_remark_text,track_route_text,trailmarks_next,trailmarks_extension,technical_difficulty,endurance_difficulty,distance_exact,time_exact,direction_sign_id,sign_track_data_status,track_geometry) VALUES 
('Vaskapu turistaház',NULL,NULL,NULL,NULL,'{}','',NULL,NULL,39,0,1,'computed',NULL)
,('Vaskapu nyerge',NULL,NULL,NULL,NULL,'{}','',NULL,NULL,5,0,4,'computed',NULL)
,('Esztergom, Hajóállomás',NULL,NULL,NULL,NULL,'{}','',NULL,NULL,25,0,8,'computed',NULL)
,('Vaskapu turistaház',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,119,NULL,11,'computed',NULL)
,('Fári-kút',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,3152,NULL,20,'computed',NULL)
,('Fári-kút',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,3600,NULL,19,'computed',NULL)
,('Vaskapu nyerge',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,453,NULL,18,'computed',NULL)
,('Fári-kút',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,3520,NULL,17,'computed',NULL)
,('Vaskapu nyerge',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,374,NULL,16,'computed',NULL)
,('Fári-kút',NULL,NULL,NULL,NULL,'{z}','',NULL,NULL,5808,NULL,15,'computed',NULL)
;
INSERT INTO public.sign_track_data (destination_text,distance_text_rounded,time_text_rounded,track_remark_text,track_route_text,trailmarks_next,trailmarks_extension,technical_difficulty,endurance_difficulty,distance_exact,time_exact,direction_sign_id,sign_track_data_status,track_geometry) VALUES 
('Fári-kút',NULL,NULL,NULL,NULL,'{z}','',NULL,NULL,2263,NULL,14,'computed',NULL)
,('Fári-kút',NULL,NULL,NULL,NULL,'{z}','',NULL,NULL,1940,NULL,21,'computed',NULL)
,('Vaskapu turistaház',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,3559,NULL,5,'computed',NULL)
,('Vaskapu turistaház',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,408,NULL,3,'computed',NULL)
,('Esztergom, Hajóállomás',NULL,NULL,NULL,NULL,'{z}','',NULL,NULL,3570,NULL,12,'computed',NULL)
,('Esztergom, Hajóállomás',NULL,NULL,NULL,NULL,'{z}','',NULL,NULL,5833,NULL,9,'computed',NULL)
,('Vaskapu turistaház',NULL,NULL,NULL,NULL,'{z}','>p',NULL,NULL,2382,NULL,6,'computed',NULL)
,('Vaskapu turistaház',NULL,NULL,NULL,NULL,'{z}','>p',NULL,NULL,442,NULL,2,'computed',NULL)
,('Fári-kút',NULL,NULL,NULL,NULL,'{}','',NULL,NULL,0,0,13,'computed',NULL)
,('Vaskapu turistaház',NULL,NULL,NULL,NULL,'{zq}','>z>p',NULL,NULL,1137,NULL,7,'computed',NULL)
;
INSERT INTO public.sign_track_data (destination_text,distance_text_rounded,time_text_rounded,track_remark_text,track_route_text,trailmarks_next,trailmarks_extension,technical_difficulty,endurance_difficulty,distance_exact,time_exact,direction_sign_id,sign_track_data_status,track_geometry) VALUES 
('Esztergom, Hajóállomás',NULL,NULL,NULL,NULL,'{z}','',NULL,NULL,3893,NULL,23,'computed',NULL)
,('Vaskapu nyerge',NULL,NULL,NULL,NULL,'{p}','',NULL,NULL,3157,NULL,24,'computed',NULL)
;