INSERT INTO public.direction_sign (is_existing,realization_priority,realization_reason,next_direction_sign_id,next_trail_id,destination_id,is_destination_sign,placement_angle,placement_face,placement_index,is_dirty,is_invalid,invalidity_error_message,time_override_until_next_sign,"location") VALUES 
(false,NULL,'newly_planned_sign',NULL,NULL,139,true,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.771630300000005 47.7868091)')
,(false,NULL,'newly_planned_sign',NULL,NULL,NULL,true,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.774349199999993 47.78473129999999)')
,(false,NULL,'newly_planned_sign',NULL,NULL,NULL,true,0,NULL,NULL,false,false,NULL,NULL,'POINT (18.731827599999992 47.792798099999985)')
,(false,NULL,'newly_planned_sign',1,3,NULL,false,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.7715719 47.78751729999999)')
,(false,NULL,'newly_planned_sign',1,33,NULL,false,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.79118010000001 47.785164199999976)')
,(false,NULL,'newly_planned_sign',1,33,NULL,false,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.774349199999993 47.78473129999999)')
,(false,NULL,'newly_generated_recommended_sign',4,3,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.7715719 47.78751729999999)')
,(false,NULL,'newly_generated_recommended_sign',4,3,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.771630300000005 47.7868091)')
,(false,NULL,'newly_generated_intermediate_sign',8,34,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.7715719 47.78751729999999)')
,(false,NULL,'newly_planned_sign',8,34,NULL,false,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.79118010000001 47.785164199999976)')
;
INSERT INTO public.direction_sign (is_existing,realization_priority,realization_reason,next_direction_sign_id,next_trail_id,destination_id,is_destination_sign,placement_angle,placement_face,placement_index,is_dirty,is_invalid,invalidity_error_message,time_override_until_next_sign,"location") VALUES 
(false,NULL,'newly_generated_recommended_sign',13,4,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.731827599999992 47.792798099999985)')
,(false,NULL,'newly_planned_sign',13,4,NULL,false,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.7715719 47.78751729999999)')
,(false,NULL,'newly_generated_recommended_sign',13,4,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.775208300000003 47.788505299999976)')
,(false,NULL,'newly_generated_recommended_sign',13,3,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.774349199999993 47.78473129999999)')
,(false,NULL,'newly_generated_recommended_sign',13,3,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.7715719 47.78751729999999)')
,(false,NULL,'newly_generated_recommended_sign',13,3,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.771630300000005 47.7868091)')
,(false,NULL,'newly_planned_sign',11,34,NULL,false,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.79118010000001 47.785164199999976)')
,(false,NULL,'newly_planned_sign',11,34,NULL,false,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.775208300000003 47.788505299999976)')
,(false,NULL,'newly_planned_sign',NULL,NULL,NULL,true,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.79118010000001 47.785164199999976)')
,(false,NULL,'newly_planned_sign',2,20,NULL,false,NULL,NULL,NULL,false,false,NULL,NULL,'POINT (18.774395199999997 47.79167679999998)')
;
INSERT INTO public.direction_sign (is_existing,realization_priority,realization_reason,next_direction_sign_id,next_trail_id,destination_id,is_destination_sign,placement_angle,placement_face,placement_index,is_dirty,is_invalid,invalidity_error_message,time_override_until_next_sign,"location") VALUES 
(false,NULL,'newly_generated_intermediate_sign',8,34,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.775208300000003 47.788505299999976)')
,(false,NULL,'newly_generated_recommended_sign',4,33,NULL,false,NULL,NULL,NULL,false,NULL,NULL,NULL,'POINT (18.79118010000001 47.785164199999976)')
;