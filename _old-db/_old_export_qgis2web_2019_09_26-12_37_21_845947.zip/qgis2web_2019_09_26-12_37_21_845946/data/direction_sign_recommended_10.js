var json_direction_sign_recommended_10 = {
"type": "FeatureCollection",
"name": "direction_sign_recommended_10",
"crs": { "type": "name", "properties": { "name": "urn:ogc:def:crs:OGC:1.3:CRS84" } },
"features": [

]
}
